# PEARLHUSH — GitHub Pages Website

A responsive static website for PEARLHUSH jewellery.

## Files

- `index.html` — website structure and content
- `style.css` — design and responsive styling
- `script.js` — products, filtering and WhatsApp ordering
- `assets/` — add your own product/hero images here

## Before publishing

Open `script.js` and replace:

`919999999999`

with the PEARLHUSH WhatsApp number.

Open `index.html` and update:

- Instagram URL
- Email address
- Product names/prices
- Shipping timeline
- Product claims
- Policies

## Add images

Put your images inside `assets/`.

The hero image is referenced as:

`assets/hero.jpg`

You can later replace the CSS product placeholders with real product images.

## GitHub Pages

1. Create a GitHub account.
2. Create a new repository, e.g. `pearlhush`.
3. Upload `index.html`, `style.css`, `script.js`, `README.md` and the `assets` folder.
4. Go to **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`.
7. Save.
8. GitHub will provide your website URL.

For a custom domain such as `www.pearlhush.in`, buy the domain separately and configure it under GitHub Pages settings.
