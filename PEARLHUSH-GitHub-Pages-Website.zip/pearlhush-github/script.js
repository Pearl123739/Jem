const products = [
  { name: "Pearl Heart Chain", category: "Chain", price: 799, badge: "BESTSELLER" },
  { name: "Classic Heart Bracelet", category: "Bracelet", price: 699, badge: "ANTI-TARNISH" },
  { name: "Dainty Drop Earrings", category: "Earrings", price: 599, badge: "NEW" },
  { name: "Minimal Glow Ring", category: "Ring", price: 499, badge: "EVERYDAY" },
  { name: "Triple Heart Chain", category: "Chain", price: 899, badge: "ANTI-TARNISH" },
  { name: "Slim Charm Bracelet", category: "Bracelet", price: 649, badge: "NEW" },
  { name: "Pearl Stud Earrings", category: "Earrings", price: 549, badge: "BESTSELLER" },
  { name: "Twist Detail Ring", category: "Ring", price: 599, badge: "EVERYDAY" }
];

function productCard(p) {
  return `
    <article class="product-card">
      <div class="product-image" aria-label="${p.name} image placeholder"></div>
      <div class="product-info">
        <span class="badge">${p.badge}</span>
        <h3>${p.name}</h3>
        <div class="price">₹${p.price.toLocaleString("en-IN")}</div>
        <button onclick="orderProduct('${p.name}', ${p.price})">ORDER ON WHATSAPP</button>
      </div>
    </article>`;
}

function renderProducts(list, id) {
  document.getElementById(id).innerHTML = list.map(productCard).join("");
}

function filterProducts() {
  const value = document.getElementById("categoryFilter").value;
  const filtered = value === "all" ? products : products.filter(p => p.category === value);
  renderProducts(filtered, "shopGrid");
}

function orderProduct(name, price) {
  const phone = "919999999999"; // REPLACE WITH YOUR REAL WHATSAPP NUMBER
  const message = `Hi PEARLHUSH, I would like to order ${name} for ₹${price}. Please share the order details.`;
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank");
}

function subscribe(event) {
  event.preventDefault();
  document.getElementById("subscribeMessage").textContent =
    "Thank you for joining the PEARLHUSH circle ✨";
  document.getElementById("email").value = "";
}

function toggleMenu() {
  document.getElementById("nav").classList.toggle("open");
}

renderProducts(products.slice(0, 4), "productGrid");
renderProducts(products, "shopGrid");
